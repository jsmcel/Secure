import { registerRootComponent } from 'expo';
import App from './App';

console.log('🔥 Index.js loading App...');

registerRootComponent(App);
